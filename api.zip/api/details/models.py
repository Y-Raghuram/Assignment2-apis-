from django.db import models

class Details (models.Model):
    employee_name = models.CharField(max_length=100)
    age = models.CharField(max_length=100)
    employee_deparment = models.CharField(max_length=100)


   
