from rest_framework.viewsets import ModelViewSet
from .models import Details
from .serializer import Detail
from rest_framework.filters import SearchFilter, OrderingFilter


class DetailViewSet (ModelViewSet):
    serializer_class = Detail
    queryset = Details.objects.all()
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['employee_name']
